package org.mykola.HebrewStudy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HebrewStudyApplicationTests {

	@Test
	void contextLoads() {
	}

}
